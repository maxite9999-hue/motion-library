"""Fixed native motion + localized, replaceable text. Not vector reconstruction.
Usage: python3 render-faithful.py recipe.json options.json output.mp4 source_dir
Requires Pillow, numpy, opencv-python and ffmpeg. No generated extra headings.
"""
from pathlib import Path
import sys,json,subprocess as sp,functools
import numpy as np
from PIL import Image,ImageDraw,ImageFont
try:import cv2
except ImportError:
    sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'work/cn-rebuild/deps'));import cv2
FONT_PATH=next(Path('/System/Library/AssetsV2').glob('**/PingFang.ttc'),None)
@functools.lru_cache(2)
def face(weight):
    return ImageFont.truetype(str(FONT_PATH),180,index=11 if weight=='Medium' else 15) if FONT_PATH else ImageFont.truetype(f'/System/Library/Fonts/STHeiti {weight}.ttc',180,index=1)

@functools.lru_cache(512)
def glyph(s,w,h,weight,shown=None):
    f=face(weight)
    b=f.getbbox(s)
    common_h=max(1,b[3]-b[1]);advance=sum(f.getlength(c) for c in s)
    gap=max(0,(w*common_h/max(1,h)-advance)/max(1,len(s)-1))
    im=Image.new('L',(round(advance+gap*max(0,len(s)-1))+12,common_h+4));d=ImageDraw.Draw(im);x=4
    # Every character shares one baseline and cap-height coordinate system.
    # In particular, the single stroke 一 must never be stretched to cap height.
    positions=[]
    for c in s:
        positions.append((x,c))
        d.text((x,2-b[1]),c,font=f,fill=255);x+=f.getlength(c)+gap
    bounds=im.getbbox()
    if shown is not None:
        im=Image.new('L',im.size);d=ImageDraw.Draw(im)
        for x,c in positions[:shown]:d.text((x,2-b[1]),c,font=f,fill=255)
    if bounds:im=im.crop(bounds)
    return np.asarray(im.resize((max(1,w),max(1,h)),Image.Resampling.LANCZOS))

def measure(native,tr,f):
    x0,y0,x1,y1=tr['roi'];crop=native[y0:y1,x0:x1];ch=crop[:,:,2]
    dark=tr['ink']=='dark';kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(41,41))
    if dark:
        # Gold plate: foreground is dark in all channels, never the smoke itself.
        score=cv2.morphologyEx(cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY),cv2.MORPH_BLACKHAT,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(81,81)))
        mask=(score>8)&(crop[:,:,0]<155)&(crop[:,:,1]<150)
    else:
        score=cv2.morphologyEx(ch,cv2.MORPH_TOPHAT,kernel)
        rgb=crop.astype(np.float32)
        mask=(score>8)&(rgb[:,:,0]>155)&(rgb[:,:,1]>125)&(rgb[:,:,2]>rgb[:,:,1]*.76)
    count,labels,stats,centroids=cv2.connectedComponentsWithStats(mask.astype(np.uint8),8)
    good=np.zeros(mask.shape,np.uint8)
    for i in range(1,count):
        if stats[i,cv2.CC_STAT_AREA]>=tr.get('minArea',10):good[labels==i]=255
    ys,xs=np.where(good)
    if len(xs)<tr.get('minPixels',65):return None
    bbox=[int(xs.min()+x0),int(ys.min()+y0),int(xs.max()+x0+1),int(ys.max()+y0+1)]
    colors=crop[good>0];color=np.percentile(colors,35 if dark else 85,axis=0).astype(np.uint8)
    return bbox,good,color

def frame(native,tracks,options,f):
    out=native.copy();allowed=np.zeros(native.shape[:2],bool);records=[]
    for tr in tracks:
        if not tr['start']<=f<tr['end']:continue
        if tr.get('fadingPlate'):
            x0,y0,x1,y1=tr['roi'];crop=native[y0:y1,x0:x1].astype(np.float32);hh,ww=crop.shape[:2]
            u=np.linspace(0,1,ww)[None,:,None];v=np.linspace(0,1,hh)[:,None,None]
            corners=(1-v)*((1-u)*crop[0,0]+u*crop[0,-1])+v*((1-u)*crop[-1,0]+u*crop[-1,-1])
            plate=np.clip((1-v)*crop[0:1]+v*crop[-1:]+(1-u)*crop[:,0:1]+u*crop[:,-1:]-corners,0,255)
            # Measure source fade against the smooth plate, including faint frames
            # that ordinary OCR and hard foreground thresholds miss.
            dark=tr['ink']=='dark'
            residual=plate.mean(2)-crop.mean(2) if dark else crop[:,:,2]-plate[:,:,2]
            divisor=np.median(plate.mean(2))-50 if dark else 245-np.median(plate[:,:,2])
            opacity=float(np.clip(np.percentile(residual,99)/max(1,divisor),0,1))
            out[y0:y1,x0:x1]=plate.astype(np.uint8);allowed[y0:y1,x0:x1]=True
            x,y,r,b=tr['lockedBox'];a=glyph(options.get(tr['key'],tr['text']),r-x,b-y,tr.get('weight','Light')).astype(np.float32)/255*opacity
            color=np.array([50,50,47] if dark else [245,240,223]);dst=out[y:b,x:r].astype(float);out[y:b,x:r]=(dst*(1-a[:,:,None])+color*a[:,:,None]).astype(np.uint8);allowed[y:b,x:r]|=a>0
            records.append({'key':tr['key'],'box':[x,y,r,b],'opacity':opacity});continue
        if tr.get('aboveDotArray'):
            dark=(native[:,:,0]<105)&(native[:,:,1]<95)&(native[:,:,2]<95)
            count,labels,stats,_=cv2.connectedComponentsWithStats(dark.astype(np.uint8),8)
            dots=[s for s in stats[1:] if 8<=s[cv2.CC_STAT_AREA]<=2000 and .45<s[2]/max(1,s[3])<1.8]
            if not dots:continue
            left=min(s[0] for s in dots);top=min(s[1] for s in dots);right=max(s[0]+s[2] for s in dots)
            hh=round((right-left)*.21)
            tr=dict(tr,roi=[max(0,left-18),max(0,top-round(hh*1.6)),min(1280,right+18),max(1,top-5)])
        found=measure(native,tr,f)
        if found is None:continue
        box,mask,color=found;x0,y0,x1,y1=tr['roi'];pad=cv2.dilate(mask,np.ones((11,11),np.uint8))
        # Only masked source glyphs are repaired; no full-screen generic plate.
        crop=out[y0:y1,x0:x1];crop[:]=cv2.inpaint(crop,pad,11,cv2.INPAINT_TELEA);allowed[y0:y1,x0:x1]|=pad>0
        box=np.array(box,dtype=int);angle=tr.get('angle',0);reveal=1.
        if 'fullBox' in tr and f<tr.get('revealEnd',tr['start']):
            target=np.array(tr['fullBox'])
            reveal=np.clip((target[3]-box[1])/max(1,target[3]-target[1]) if angle else (box[2]-target[0])/max(1,target[2]-target[0]),0,1);box=target
        elif 'lockedBox' in tr:box=np.array(tr['lockedBox'])
        x,y,r,b=box;w,h=r-x,b-y
        if w<2 or h<2:continue
        value=options.get(tr['key'],tr['text'])
        shown=max(1,int(len(value)*reveal)) if reveal<.99 else None
        a=glyph(value,h if angle else w,w if angle else h,tr.get('weight','Light'),shown)
        if angle:a=np.rot90(a)
        tile=np.broadcast_to(color,(h,w,3)).copy()
        xa=max(0,x);ya=max(0,y);xb=min(1280,r);yb=min(720,b)
        alpha=a[ya-y:yb-y,xa-x:xb-x].astype(np.float32)/255
        if alpha.size:
            dst=out[ya:yb,xa:xb].astype(float);out[ya:yb,xa:xb]=(dst*(1-alpha[:,:,None])+tile[ya-y:yb-y,xa-x:xb-x]*alpha[:,:,None]).astype(np.uint8)
            allowed[ya:yb,xa:xb]|=alpha>0
        records.append({'key':tr['key'],'box':box.tolist(),'reveal':float(reveal)})
    assert not np.any(out[~allowed]!=native[~allowed]),'Pixels changed outside localized text masks'
    return out,allowed,records

def render(recipe,options,dest,source):
    spec=json.loads(Path(recipe).read_text());source=Path(source);dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    assert set(options)<=set(spec['demoOptions']),'Unknown text slot'
    dec=sp.Popen(['ffmpeg','-v','error','-threads','2','-i',str(source/spec['reference']),'-an','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=sp.PIPE)
    enc=sp.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','pipe:0','-i',str(source/spec['audio']),'-map','0:v','-map','1:a','-frames:v',str(spec['frames']),'-c:v','libx264','-threads','2','-preset','fast','-crf','16','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(dest)],stdin=sp.PIPE)
    record=[];edited=0
    for f in range(spec['frames']):
        raw=dec.stdout.read(1280*720*3);assert len(raw)==1280*720*3
        native=np.frombuffer(raw,np.uint8).reshape(720,1280,3)
        if any(a<=f<b for a,b in spec.get('blackRanges',[])):out=native;rows=[]
        else:out,mask,rows=frame(native,spec['tracks'],options,f)
        if rows:edited+=1;record.append({'frame':f,'tracks':rows})
        enc.stdin.write(out.tobytes())
    enc.stdin.close();dec.stdout.close();assert enc.wait()==0 and dec.wait()==0
    Path(str(dest)+'.runtime.json').write_text(json.dumps({'id':spec['id'],'frames':spec['frames'],'editedFrames':edited,'outsideTextMasksPreEncodeExact':True,'motionType':'fixed native motion, replaceable text','samples':record},ensure_ascii=False))
    print(spec['id'],edited,'localized frames',flush=True)

if __name__=='__main__':render(sys.argv[1],json.loads(Path(sys.argv[2]).read_text()),sys.argv[3],sys.argv[4])
