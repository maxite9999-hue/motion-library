ML-007 中文按钮复用模板
助手使用：安装 pillow、numpy、opencv-python-headless 与 FFmpeg，然后运行 python3 render-ML-007.py demo-options.json output.mp4。
只更改两项按钮文字，每项1至4个汉字。原片、混音与中文演示相互独立。非逐像素复刻；光标交叠与收尾单帧近似修补。
