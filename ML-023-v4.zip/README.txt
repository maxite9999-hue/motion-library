ML-023 中文可改模板
这是可复用的结构重建，不宣称逐帧复刻。原片另存供对照。
助手用 Python 3 + Pillow + numpy + FFmpeg，安装中文字体后执行：
python3 render-v4.py ML-023.json demo-options.json result.mp4
用户只须提供编号、文案和录音。修改 demo-options 中对应字段即可生成新文字；可用 asset/footage/person1Asset 等替换媒体。
音乐与音效保留为原混音，不是独立分轨。示例财富数据来自历史原片。
