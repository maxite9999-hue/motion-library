ML-009 原生画面与音轨＋八个可替换文字字段。
由助手按新文案替换，用户只需复制模板编号。
保留原版大标题、两组三行正文、结尾小字、原下划线及淡出；不新增角标。
原视频素材和运动固定，文字处底图为局部修补，非全图像素一致、非全参数化工程。
运行环境：Python 3、Pillow、numpy、opencv-python、FFmpeg，macOS PingFang 字体。
命令：python3 render-faithful.py ML-009-v5.json demo-options.json result.mp4 .
