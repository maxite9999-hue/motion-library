Native motion + replaceable localized text. Not pixel-exact. New SFX only.
python3 render-faithful-v6l.py ML-014-v6.json demo-options.json output.mp4 .
