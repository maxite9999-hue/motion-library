ML-052 原片运动和音轨＋十个可替换中文文字字段。
由助手按文案替换，用户只需复制模板编号。
公路提问、白色闪光、城市标题、说明页及其淡出按原片切换；保留音乐音效，不增加角标。
底层视频、相机运动及时间固定；文字处底图为局部近似修补，非全参数化工程。
环境：Python 3、Pillow、numpy、opencv-python、FFmpeg，macOS PingFang字体。
命令：python3 render-faithful.py ML-052-v5.json demo-options.json result.mp4 .
