原生画面运动＋可替换中文文字。音轨仅来自用户新给的纯音效视频；旧背景音乐和旧音效不混入。文字背景为局部近似修补，不是全画面像素相同，也不是完全参数化动画。复制ML编号交给助手即可，无需手工修改。
python3 render-faithful-v6.py ML-033-v6.json demo-options.json output.mp4 .
