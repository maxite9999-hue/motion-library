保留原素材运动，局部文字可替换。背景局部近似修补，不是全参数化或全图像素一致。只使用新纯音效。
python3 render-faithful-v6k.py ML-044-v6.json demo-options.json output.mp4 .
