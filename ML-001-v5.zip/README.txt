ML-001 原生运动＋可替换文字
用户只需提供模板编号、文案和录音，以下操作由助手完成。
参考运动及源混合音轨固定保留，不是每个黑点都独立可调的矢量工程。中文新字形与文字处背景修补不等同于英文原片像素。
助手环境：Python 3、Pillow、numpy、opencv-python、FFmpeg；Mac PingFang 或 Heiti 字体。
执行：python3 render-faithful.py ML-001-v5.json demo-options.json result.mp4 .
每个字段对应源片文字块，文案须精简匹配原版长度；不能为了塞长句取消原字号差距、分行或运动。
